Webstite URL (CloudFront): https://dhzq906gzvz5j.cloudfront.net

Bucket URL: http://my-2909495-bucket.s3-website-us-west-2.amazonaws.com/

I could not upload bootstrap folder, it took me hours and the throuput is too low, so I uploaded the webshite without bootstrap
